//Created by Tom 
#include "mbed.h"

//Instanciamos las entradas analogicas
float estado; 
AnalogIn entrada_pot(p20);
DigitalOut Led(p19);

//Configuramos la coneccion con terminal
Serial pc(USBTX,USBRX);

 
int main()
{
    pc.printf("Valor del potenciometro\n\r");
    while(1)
        {
            estado = entrada_pot;
            pc.printf("%f \n \r ", estado);
                if(estado == 1){
                     Led = 1;   
                        wait(1);
                    }else{
                        Led = 0; 
                        wait(1);
                    }
            wait(0.5);      
            
        }
}
    